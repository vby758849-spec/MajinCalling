package com.majin.calling

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.util.concurrent.Executors

/**
 * Bina internet ke call: dono phone same WiFi / hotspot par hon.
 * Audio UDP se seedha phone se phone jaati hai (8 kHz, 16-bit, mono).
 */
class LocalCallActivity : AppCompatActivity() {

    companion object {
        const val PORT = 50123
        const val RATE = 8000
        const val FRAME = 160 // 20 ms

        const val IDLE = 0
        const val CALLING = 1
        const val INCOMING = 2
        const val INCALL = 3

        const val T_AUDIO: Byte = 0
        const val T_RING: Byte = 1
        const val T_ACCEPT: Byte = 2
        const val T_BYE: Byte = 3
    }

    @Volatile private var state = IDLE
    @Volatile private var peer: InetAddress? = null
    @Volatile private var muted = false
    @Volatile private var destroyed = false

    private var socket: DatagramSocket? = null
    private var rec: AudioRecord? = null
    private var track: AudioTrack? = null
    private val sender = Executors.newSingleThreadExecutor()
    private lateinit var audio: AudioManager

    private lateinit var myIpView: TextView
    private lateinit var peerInput: EditText
    private lateinit var statusView: TextView
    private lateinit var callBtn: Button
    private lateinit var acceptBtn: Button
    private lateinit var hangBtn: Button
    private lateinit var muteBtn: Button
    private lateinit var speakerBtn: Button

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                listen()
            } else {
                Toast.makeText(this, "Mic ki permission chahiye.", Toast.LENGTH_LONG).show()
                finish()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        buildUi()
        updateUi()

        val has = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (has) listen() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    override fun onResume() {
        super.onResume()
        myIpView.text = localIps()
    }

    // ---------- UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun button(text: String, bg: Int, fg: Int, onClick: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 17f
            setTextColor(fg)
            setBackgroundColor(bg)
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52)
            ).apply { topMargin = dp(10) }
        }

    private fun buildUi() {
        val bg = Color.parseColor("#0F1419")
        val fg = Color.parseColor("#EEF2F6")
        val mutedColor = Color.parseColor("#8B9AAB")
        val accent = Color.parseColor("#FF7A1A")
        val line = Color.parseColor("#26323F")
        val bad = Color.parseColor("#FF4D4F")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(20), dp(48), dp(20), dp(20))
        }

        root.addView(label("Bina net ke call", 24f, fg, true))
        root.addView(label(
            "Dono phone same WiFi ya hotspot se jude hon. Internet chalu hona zaroori nahi.",
            14f, mutedColor
        ).apply { setPadding(0, dp(4), 0, dp(20)) })

        root.addView(label("AAPKA IP", 12f, mutedColor))
        myIpView = label("...", 20f, accent, true).apply { setPadding(0, dp(4), 0, dp(16)) }
        myIpView.setTextIsSelectable(true)
        root.addView(myIpView)

        peerInput = EditText(this).apply {
            hint = "Dost ka IP, jaise 192.168.43.1"
            setHintTextColor(mutedColor)
            setTextColor(fg)
            setBackgroundColor(line)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            inputType = InputType.TYPE_CLASS_TEXT
            textSize = 18f
            setSingleLine()
        }
        root.addView(peerInput)

        callBtn = button("Call karo", accent, Color.parseColor("#1A0E02")) {
            val ip = peerInput.text.toString().trim()
            if (!Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(ip)) {
                statusView.text = "Sahi IP likho, jaise 192.168.43.1"
            } else {
                placeCall(ip)
            }
        }
        root.addView(callBtn)

        acceptBtn = button("Jawab do", Color.parseColor("#3ECF8E"), Color.parseColor("#04210F")) {
            acceptCall()
        }
        root.addView(acceptBtn)

        muteBtn = button("Mute", line, fg) {
            muted = !muted
            muteBtn.text = if (muted) "Unmute" else "Mute"
        }
        root.addView(muteBtn)

        speakerBtn = button("Speaker chalu karo", line, fg) {
            val on = !audio.isSpeakerphoneOn
            audio.isSpeakerphoneOn = on
            speakerBtn.text = if (on) "Speaker band karo" else "Speaker chalu karo"
        }
        root.addView(speakerBtn)

        hangBtn = button("Call khatam", bad, Color.WHITE) {
            endCall(true, "Call khatam.")
        }
        root.addView(hangBtn)

        statusView = label("", 15f, mutedColor).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(18), 0, 0)
        }
        root.addView(statusView)

        root.addView(label(
            "Tip: ek phone ka hotspot on karo, doosra usse jode. Hotspot wale phone ka IP aksar 192.168.43.1 hota hai.",
            12f, mutedColor
        ).apply { setPadding(0, dp(24), 0, 0) })

        setContentView(root)
    }

    private fun updateUi() {
        fun vis(v: View, show: Boolean) { v.visibility = if (show) View.VISIBLE else View.GONE }
        vis(peerInput, state == IDLE)
        vis(callBtn, state == IDLE)
        vis(acceptBtn, state == INCOMING)
        vis(muteBtn, state == INCALL)
        vis(speakerBtn, state == INCALL)
        vis(hangBtn, state != IDLE)
        hangBtn.text = when (state) {
            INCOMING -> "Radd karo"
            CALLING -> "Radd karo"
            else -> "Call khatam"
        }
    }

    private fun setState(s: Int, msg: String? = null) {
        state = s
        runOnUiThread {
            if (msg != null) statusView.text = msg
            updateUi()
        }
    }

    // ---------- Network ----------

    private fun localIps(): String {
        val list = mutableListOf<String>()
        try {
            val ifs = NetworkInterface.getNetworkInterfaces()
            while (ifs.hasMoreElements()) {
                val ni = ifs.nextElement()
                if (!ni.isUp || ni.isLoopback) continue
                val addrs = ni.inetAddresses
                while (addrs.hasMoreElements()) {
                    val a = addrs.nextElement()
                    if (a is Inet4Address && !a.isLoopbackAddress) list.add(a.hostAddress ?: "")
                }
            }
        } catch (_: Exception) {
        }
        return if (list.isEmpty()) "WiFi/hotspot se jude nahi" else list.joinToString("  |  ")
    }

    private fun listen() {
        Thread {
            try {
                val s = DatagramSocket(null)
                s.reuseAddress = true
                s.bind(InetSocketAddress(PORT))
                socket = s
                val buf = ByteArray(2048)
                val pkt = DatagramPacket(buf, buf.size)
                while (!s.isClosed) {
                    pkt.length = buf.size
                    s.receive(pkt)
                    val from = pkt.address
                    if (pkt.length < 1) continue
                    when (buf[0]) {
                        T_RING -> if (state == IDLE) {
                            peer = from
                            setState(INCOMING, "${from.hostAddress} call kar raha hai")
                        }
                        T_ACCEPT -> if (state == CALLING && from == peer) {
                            startAudio()
                        }
                        T_BYE -> if (state != IDLE && from == peer) {
                            endCall(false, "Call khatam ho gayi.")
                        }
                        T_AUDIO -> if (state == INCALL && from == peer) {
                            track?.write(buf, 1, pkt.length - 1)
                        }
                    }
                }
            } catch (e: Exception) {
                if (!destroyed) {
                    runOnUiThread { statusView.text = "Network mein dikkat: ${e.message}" }
                }
            }
        }.start()
    }

    private fun sendCtl(type: Byte, to: InetAddress) {
        sender.execute {
            try {
                socket?.send(DatagramPacket(byteArrayOf(type), 1, to, PORT))
            } catch (_: Exception) {
            }
        }
    }

    // ---------- Call flow ----------

    private fun placeCall(ip: String) {
        val addr = try { InetAddress.getByName(ip) } catch (_: Exception) { null }
        if (addr == null) {
            statusView.text = "IP samajh nahi aaya."
            return
        }
        peer = addr
        setState(CALLING, "Ring ja rahi hai...")
        Thread {
            var t = 0
            while (state == CALLING && t < 30) {
                sendCtl(T_RING, addr)
                try { Thread.sleep(1000) } catch (_: InterruptedException) {}
                t++
            }
            if (state == CALLING) endCall(false, "Jawab nahi mila.")
        }.start()
    }

    private fun acceptCall() {
        val p = peer ?: return
        sendCtl(T_ACCEPT, p)
        startAudio()
    }

    @SuppressLint("MissingPermission")
    private fun startAudio() {
        val p = peer ?: return
        try {
            audio.mode = AudioManager.MODE_IN_COMMUNICATION
            audio.isSpeakerphoneOn = false

            val minT = AudioTrack.getMinBufferSize(
                RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(RATE)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minT, FRAME * 2 * 4))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            val minR = AudioRecord.getMinBufferSize(
                RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val r = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minR, FRAME * 2 * 4)
            )

            track = t
            rec = r
            muted = false
            t.play()
            r.startRecording()
        } catch (e: Exception) {
            endCall(true, "Audio shuru nahi hua: ${e.message}")
            return
        }

        setState(INCALL, "Call chal rahi hai")
        runOnUiThread {
            muteBtn.text = "Mute"
            speakerBtn.text = "Speaker chalu karo"
        }

        Thread {
            val shorts = ShortArray(FRAME)
            val out = ByteArray(1 + FRAME * 2)
            out[0] = T_AUDIO
            while (state == INCALL) {
                val r = rec ?: break
                val n = try { r.read(shorts, 0, FRAME) } catch (_: Exception) { -1 }
                if (n <= 0) break
                if (muted) continue
                for (i in 0 until n) {
                    out[1 + i * 2] = (shorts[i].toInt() and 0xFF).toByte()
                    out[2 + i * 2] = ((shorts[i].toInt() shr 8) and 0xFF).toByte()
                }
                try {
                    socket?.send(DatagramPacket(out, 1 + n * 2, p, PORT))
                } catch (_: Exception) {
                }
            }
        }.start()
    }

    private fun releaseAudio() {
        try { rec?.stop() } catch (_: Exception) {}
        try { rec?.release() } catch (_: Exception) {}
        try { track?.stop() } catch (_: Exception) {}
        try { track?.release() } catch (_: Exception) {}
        rec = null
        track = null
        try {
            audio.isSpeakerphoneOn = false
            audio.mode = AudioManager.MODE_NORMAL
        } catch (_: Exception) {
        }
    }

    private fun endCall(notify: Boolean, msg: String) {
        val p = peer
        val wasActive = state != IDLE
        state = IDLE
        if (notify && wasActive && p != null) sendCtl(T_BYE, p)
        releaseAudio()
        peer = null
        runOnUiThread {
            statusView.text = msg
            updateUi()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (state != IDLE) endCall(true, "Call khatam.") else super.onBackPressed()
    }

    override fun onDestroy() {
        destroyed = true
        val p = peer
        val wasActive = state != IDLE
        state = IDLE
        releaseAudio()
        val s = socket
        Thread {
            try {
                if (wasActive && p != null) s?.send(DatagramPacket(byteArrayOf(T_BYE), 1, p, PORT))
            } catch (_: Exception) {
            }
            try { s?.close() } catch (_: Exception) {}
        }.start()
        sender.shutdown()
        super.onDestroy()
    }
}
